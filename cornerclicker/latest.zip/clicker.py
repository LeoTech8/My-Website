import tkinter as tk
from tkinter import messagebox
import json
import os
import random

# ===== GAME VARIABLES =====
clicks = 0
clicks_per_press = 1
clicks_per_second = 0
cps_cost = 50
transparent = False

# ===== SAVE LOCATION =====
home_dir = os.path.expanduser("~")
save_dir = os.path.join(home_dir, "CornerClicker/saves")
os.makedirs(save_dir, exist_ok=True)

save_file = os.path.join(save_dir, "clicks.json")
ach_file = os.path.join(save_dir, "achievements.json")
setting_file = os.path.join(save_dir, "settings.json")

# ===== ACHIEVEMENTS =====
achievement_list = {
    "Fresh Start": {"condition": lambda: clicks >= 1, "unlocked": False},
    "First 100 Clicks": {"condition": lambda: clicks >= 100, "unlocked": False},
    "500 Clicks Club": {"condition": lambda: clicks >= 500, "unlocked": False},
    "1k Clicks Hero": {"condition": lambda: clicks >= 1000, "unlocked": False},
    "10k Clicks Factory": {"condition": lambda: clicks >= 10000, "unlocked": False},
    "100k?": {"condition": lambda: clicks >= 100000, "unlocked": False},
    "I MILL!": {"condition": lambda: clicks >= 1000000, "unlocked": False},
    "Getting Expensive!": {"condition": lambda: cps_cost >= 10000, "unlocked": False},
    "Can we afford this?": {"condition": lambda: cps_cost >= 1000000, "unlocked": False},
}

# ===== SAVE FUNCTIONS =====
def save_game():
    data = {
        "clicks": clicks,
        "clicks_per_press": clicks_per_press,
        "clicks_per_second": clicks_per_second,
        "cps_cost": cps_cost
    }
    with open(save_file, "w") as f:
        json.dump(data, f)

def load_game():
    global clicks, clicks_per_press, clicks_per_second, cps_cost
    if os.path.exists(save_file):
        with open(save_file) as f:
            data = json.load(f)
            clicks = data.get("clicks", 0)
            clicks_per_press = data.get("clicks_per_press", 1)
            clicks_per_second = data.get("clicks_per_second", 0)
            cps_cost = data.get("cps_cost", 50)

def save_achievements():
    data = {n: achievement_list[n]["unlocked"] for n in achievement_list}
    with open(ach_file, "w") as f:
        json.dump(data, f)

def load_achievements():
    if os.path.exists(ach_file):
        with open(ach_file) as f:
            saved = json.load(f)
            for n in achievement_list:
                achievement_list[n]["unlocked"] = saved.get(n, False)

def save_setting():
    with open(setting_file, "w") as f:
        json.dump({"transparent": transparent}, f)

def load_setting():
    global transparent
    if os.path.exists(setting_file):
        with open(setting_file) as f:
            transparent = json.load(f).get("transparent", False)

# ===== ACHIEVEMENT POPUP =====
def show_achievement_popup(text):
    popup = tk.Toplevel(root)
    popup.overrideredirect(True)
    popup.attributes("-topmost", True)

    popup.geometry("+300+300")

    frame = tk.Frame(popup, bg="black")
    frame.pack()

    label = tk.Label(
        frame,
        text=f"🏆 Achievement!\n{text}",
        fg="white",
        bg="black",
        font=("Arial", 10)
    )
    label.pack(padx=10, pady=10)

    popup.after(3000, popup.destroy)

def check_achievements():
    unlocked_any = False
    for name, data in achievement_list.items():
        if not data["unlocked"] and data["condition"]():
            data["unlocked"] = True
            unlocked_any = True
            show_achievement_popup(name)

    if unlocked_any:
        save_achievements()

# ===== FLOATING CLICK PARTICLES =====
def floating_text(x, y, text):

    particle = tk.Label(root, text=text, fg="yellow", bg="black", font=("Arial", 9, "bold"))
    particle.place(x=x, y=y)

    def animate(step=0):

        if step > 15:
            particle.destroy()
            return

        particle.place(x=x, y=y-step*2)
        root.after(30, lambda: animate(step+1))

    animate()

# ===== GAME LOGIC =====
def click_button():
    global clicks

    clicks += clicks_per_press

    x = random.randint(30, 100)
    y = random.randint(30, 60)

    floating_text(x, y, f"+{clicks_per_press}")

    update_display()
    check_achievements()

def buy_cps():
    global clicks, clicks_per_second, cps_cost

    if clicks >= cps_cost:

        clicks -= cps_cost
        clicks_per_second += 1
        cps_cost *= 2

        update_display()

def update_display():
    clicks_label.config(text=f"Clicks: {clicks}")
    cps_button.config(text=f"Buy CPS ({clicks_per_second}) Cost: {cps_cost}")
    root.title(f"Clicks: {clicks}")
    check_achievements()

def cps_loop():
    global clicks

    clicks += clicks_per_second
    update_display()
    save_game()

    root.after(1000, cps_loop)

# ===== ALWAYS ON TOP =====
def keep_on_top():
    root.attributes("-topmost", True)
    root.lift()
    root.after(1000, keep_on_top)

# ===== UI =====
root = tk.Tk()
root.overrideredirect(True)
root.attributes("-topmost", True)
root.resizable(False, False)

load_setting()

if transparent:
    root.attributes("-alpha", 0.7)
else:
    root.attributes("-alpha", 1)

# start bottom right
root.update_idletasks()
screen_w = root.winfo_screenwidth()
screen_h = root.winfo_screenheight()
root.geometry(f"160x80+{screen_w-170}+{screen_h-120}")

# ===== MENU =====
def toggle_transparent():
    global transparent

    if transparent:
        root.attributes("-alpha", 1)
        transparent = False
    else:
        root.attributes("-alpha", 0.7)
        transparent = True

    save_setting()

def show_about():
    messagebox.showinfo("About", "Corner Clicker\nVersion 0.3")

def achievments():

    aw = tk.Toplevel(root)
    aw.title("Achievements")
    aw.geometry("250x220")

    tk.Label(aw, text="Achievements", font=("Arial", 12, "bold")).pack()

    for name, data in achievement_list.items():

        status = "✅" if data["unlocked"] else "❌"

        tk.Label(
            aw,
            text=f"{status} {name}",
            font=("Arial", 10)
        ).pack(anchor="w")

def on_close():
    save_game()
    save_achievements()
    save_setting()
    root.destroy()
    quit()

menubar = tk.Menu(root)
root.config(menu=menubar)

menu = tk.Menu(menubar, tearoff=0)
settings = tk.Menu(menubar, tearoff=0)

menu.add_command(label="Achievements", command=achievments)
menu.add_command(label="About", command=show_about)
menu.add_command(label="Quit", command=on_close)

settings.add_command(label="Transparency", command=toggle_transparent)

menubar.add_cascade(label="Menu", menu=menu)
menubar.add_cascade(label="Settings", menu=settings)

# ===== BUTTONS =====
clicks_label = tk.Label(root, text="Clicks: 0", font=("Arial", 12))
clicks_label.pack()

click_button_widget = tk.Button(root, text="Click", command=click_button)
click_button_widget.pack()

cps_button = tk.Button(root, text="Buy CPS", command=buy_cps)
cps_button.pack()

# ===== DRAG + SNAP =====
def start_move(event):
    root.x = event.x
    root.y = event.y

def do_move(event):

    x = root.winfo_pointerx() - root.x
    y = root.winfo_pointery() - root.y

    root.geometry(f"+{x}+{y}")

def stop_move(event):

    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()

    win_w = root.winfo_width()
    win_h = root.winfo_height()

    x = root.winfo_x()
    y = root.winfo_y()

    snap_x = 10 if x < screen_w/2 else screen_w-win_w-10
    snap_y = 10 if y < screen_h/2 else screen_h-win_h-40

    root.geometry(f"+{snap_x}+{snap_y}")

root.bind("<ButtonPress-1>", start_move)
root.bind("<ButtonRelease-1>", stop_move)
root.bind("<B1-Motion>", do_move)

# ===== START =====
load_game()
load_achievements()

update_display()

cps_loop()
keep_on_top()

root.protocol("WM_DELETE_WINDOW", on_close)

root.mainloop()
